# Onyx-LaserTurretPlus

- Engineers laser turret won't get targeted after the first 6 seconds (the last 2 seconds after firing)
- shockwave mine is now more reliable (always knocks enemies away from laserturret or you)
- gave shockwave mine a small stun

## Special Thanks To
* The Return Of Modding Discord

## Contact
For questions or bug reports, you can find us in the [RoRR Modding Server](https://discord.gg/VjS57cszMq) @Onyx
